Indice Practicas bootstrap

<a href="https://moisesr07.github.io/practica1.html">Practica 1</a>


<a href="https://moisesr07.github.io/practica2.html">Practica 2</a>

<a href="https://moisesr07.github.io/practica3.html">Practica 3</a>

<a href="https://moisesr07.github.io/practica4.html">Practica 4</a>

<a href="https://moisesr07.github.io/practica5.html">Practica 5</a>

<a href="https://moisesr07.github.io/practica6.html">Practica 6</a>

<a href="https://moisesr07.github.io/practica8.html">Practica 8</a>
